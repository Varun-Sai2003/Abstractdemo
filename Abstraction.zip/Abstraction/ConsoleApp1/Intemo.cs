﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    interface IDbOperations 
    {
        void AddUdser();
        void DeleteUser();
    }

    class SQLServerDbOperations : IDbOperations
    {
        public void AddUdser()
        {
            Console.WriteLine("Add user Implemented with SQL Server");
        }
        public void DeleteUser()
        {
            Console.WriteLine("Delete user Implemented with SQL Server");
        }
    }

    class Intemo
    {
        static void Main(string[] args)
        {
            IDbOperations db = new SQLServerDbOperations();
            db.AddUdser();
            db.DeleteUser();
        }
    }
}
