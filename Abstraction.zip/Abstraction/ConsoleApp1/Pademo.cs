﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Product
    {
        public int id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    class Pademo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter array size:");
            int n = int.Parse(Console.ReadLine());

            Product[] ProductList = new Product[n];

            for(int i = 0;ProductList.Length > i; i++)
            {
                Console.WriteLine($"Enter Product-{i+1} details:");

                Console.WriteLine("Enter Id:");
                int _id = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Name:");
                string _name = Console.ReadLine();

                Console.WriteLine("Enter Price:");
                double _price = double.Parse(Console.ReadLine());

                Product product = new Product()
                {
                    id = _id,
                    Name = _name,
                    Price = _price
                };

                ProductList[i] = product;
            }

            Console.WriteLine("----------Product Details----------");
            foreach (Product prod in ProductList)
            {
                Console.WriteLine($"Id:{prod.id}\tName:{prod.Name}\tPrice:{prod.Price}");
            }
        }
    }
}
