﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Parent 
    {
        public Parent()
        {
            Console.WriteLine("Parent class Empty Constructor invoked!");
        }
        public Parent(string s)
        {
            Console.WriteLine("Parent Constructor with a parameter invoked!");
        }
    }

    class Child : Parent
    {
        public Child()
        {
            Console.WriteLine("Child class Empty Constructor invoked!");
        }
        public Child(string s) : base(s)
        {
            Console.WriteLine("Child Constructor with a parameter invoked!");
        }
    }
    class ConDemo1
    {
        static void Main(string[] args)
        {
            //Parent p = new Parent("game");
            Child c = new Child("game");
        }
    }
}
