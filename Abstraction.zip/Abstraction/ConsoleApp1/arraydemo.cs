﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class arraydemo
    {
        static void Main(string[] args)
        {
            //int[] scores = [98, 58, 69, 85, 77];
            Console.WriteLine("Enter the array size");
            int size = int.Parse(Console.ReadLine());

            //creating array
            string[] courseList = new string[size];

            //accepting values
            for (int i=0; i<courseList.Length; i++)
            {
                Console.WriteLine($"Enter course Title for index-{i}:");
                courseList[i] = Console.ReadLine(); 
            }

            //displaying values
            Console.WriteLine("-----------------------------Array Elements-----------------------");
            Array.Sort(courseList);
            Array.Reverse(courseList);
            //for (int i = 0; i < courseList.Length; i++)
            //{
            //    Console.WriteLine($"Course Title {i}:{courseList[i]}");
            //}

            foreach (var course in courseList)
            {
                Console.WriteLine(course);
            }


        }
    }
}
