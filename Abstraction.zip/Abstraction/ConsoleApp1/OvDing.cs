﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }

        public override string ToString()
        {
            return $"Employee Details:\n EmpID:{EmployeeId} Name:{Name} Designation:{Designation}";
        }

        public override bool Equals(object? obj)
        {
            Employee emp = (Employee)obj;
            if (emp.EmployeeId == EmployeeId && emp.Name == Name)
                return true;
            else
                return false;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode()*2;
        }

    }

    class OvDing
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee()
            {
                EmployeeId = 101,
                Name = "Amar",
                Designation = "Tester"
            };

            Employee emp2 = new Employee()
            {
                EmployeeId = 102,
                Name = "Akbar",
                Designation = "Developer"
            };

            Employee emp3 = new Employee()
            {
                EmployeeId = 103,
                Name = "Anthony",
                Designation = "Manager"
            };

            Employee emp4 = new Employee()
            {
                EmployeeId = 102,
                Name = "Akbar",
                Designation = "Developer"
            };

            Console.WriteLine(emp1.ToString());
            Console.WriteLine(emp2.ToString());
            Console.WriteLine(emp3.ToString());

            Console.WriteLine(emp2.Equals(emp4));

            Console.WriteLine(emp1.GetHashCode());


        }
    }
}