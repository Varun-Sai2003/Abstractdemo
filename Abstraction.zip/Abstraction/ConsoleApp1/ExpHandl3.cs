﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class ExpHandl3
    {
        static void Main(string[] args)
        {
            try
            {
                string s = null;
                Console.WriteLine(s.Length);
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
