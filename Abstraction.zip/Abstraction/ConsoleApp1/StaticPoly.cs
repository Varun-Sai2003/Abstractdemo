﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Arith
    {
        public void Sum(int a, int b)
        {
            Console.WriteLine(a+b);
        }

        public void Sum(double a, double b)
        {
            Console.WriteLine(a+b);
        }

        public void Sum(int a, int b, int c)
        {
            Console.WriteLine(a+b+c);
        }
    }

    class StaticPoly
    {
        static void Main(string[] args)
        {
            Arith arith = new Arith();
            arith.Sum(10, 20);
            arith.Sum(12.26, 19.25);
            arith.Sum(10, 20, 30);
        }
    }
}
