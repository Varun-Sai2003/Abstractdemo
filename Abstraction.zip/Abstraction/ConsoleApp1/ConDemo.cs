﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class sample
    {
        public sample()
        {
            Console.WriteLine("Empty Constructor Invoked!!");
        }

        public sample(string s)
        {
            Console.WriteLine("Parameter Cunstructor invoked !!");
        }
    }
    class ConDemo
    {
        static void Main(string[] args)
        {
            sample s = new sample();
            sample s1 = new sample("Bye Bye!!");

        }
    }
}
