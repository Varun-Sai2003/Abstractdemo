﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class ExpHandl
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter a number:");
                int i = int.Parse(Console.ReadLine());
                i++;
                Console.WriteLine($"After Increment:{i}");
            }
            catch(Exception ex) 
            {
                Console.WriteLine("----------Catch----------");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("----------Finally----------");
                Console.WriteLine("Finally block is executed");

            }
        }
    }
}
