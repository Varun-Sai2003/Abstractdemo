﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class ExpHandl2
    {
        static void Main(string[] args)
        {
            try
            {
                int[] arr = [98, 85, 77, 52, 66, 75];
                Console.WriteLine("Enter the index Value");
                int i = int.Parse(Console.ReadLine());
                Console.WriteLine(arr[i]);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Wrong Index Received");
            }
        }
    }
}
