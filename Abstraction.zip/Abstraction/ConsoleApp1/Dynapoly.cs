﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Bankv1
    {
        public virtual void withdraw(double amount)
        {
            Console.WriteLine("Transaction completed using NetBankig");
        }
    }

    class Bankv2 : Bankv1
    {
        public override void withdraw(double amount)
        {
            Console.WriteLine("Transaction completed using UPI");
        }
    }
    class Dynapoly
    {
        static void Main(string[] args)
        {
            Bankv1 bank = new Bankv1();
            bank.withdraw(5000);

            Bankv2 bak = new Bankv2();
            bak.withdraw(7000);

        }
    }
}
