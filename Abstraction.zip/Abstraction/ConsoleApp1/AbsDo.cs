﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    abstract class Arithm
    {
        public void Add (int x,int y)
        {
            Console.WriteLine(x + y);
        }
        public void Sub(int x, int y)
        {
            Console.WriteLine(x - y);
        }
        public abstract void Mul(int x, int y);
    }

    class D : Arithm
    {
        public override void Mul(int x, int y)
        {
            Console.WriteLine(x*y); ;
        }
    }

    class AbsDo
    {
        static void Main(string[] args)
        {
            Arithm ari = new D();
            ari.Add(10, 20);
            ari.Sub(20, 10);
            ari.Mul(10, 20);
        }
    }
}
