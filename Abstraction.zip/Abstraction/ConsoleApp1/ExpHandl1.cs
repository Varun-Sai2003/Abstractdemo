﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class ExpHandl1
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter first number:");
                int a = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter second number:");
                int b = int.Parse(Console.ReadLine());

                int c = a / b;
                Console.WriteLine($"Result is : {c}");
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("We can't divide bu zero");
            }
        }
    }
}
