﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first value:");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter second value:");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter third value:");
            int c = int.Parse(Console.ReadLine());

            if (a>b && a>c)
            {
                Console.WriteLine($"{a} is bigger than {b} and {c}");
            }
            else if (b>c)
            {
                Console.WriteLine($"{b} is bigger than {a} and {c}");
            }
            else
            {
                Console.WriteLine($"{c} is bigger than {a} and {b}");
            }
        }
    }
}