﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class InsufficientFundsException : Exception
    {
        public InsufficientFundsException():base("Insufficient funds in your account")
        {
            
        }
    }
    class ExpHandl4
    {
        static void Main(string[] args)
        {
            try
            {
                double bal = 5000;
                Console.WriteLine("Enter the amount:");
                double amount = double.Parse(Console.ReadLine());
                if (amount >= bal)
                {
                    throw new InsufficientFundsException();
                }
                else
                {
                    Console.WriteLine("Amount Withdrawn");
                    bal -= amount;
                    Console.WriteLine($"Remaining Balance:{bal}");
                }
            }
            catch (InsufficientFundsException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
