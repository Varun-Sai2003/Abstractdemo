﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class FileHandl1
    {
        static void Main(string[] args)
        {
            string fpath = @"C:\Users\csharp\Demo1.txt";
            if(File.Exists(fpath))
            {
                //using (StreamReader sr = new StreamReader(fpath))
                //{
                //    int _char = 0;
                //    while ((_char = sr.Read()) != -1)
                //    {
                //        Console.Write((char)_char);
                //    }
                //}
                Console.WriteLine(File.ReadAllText(fpath));
            }
            else
            {
                Console.WriteLine("File not Found!!");
            }

        }
    }
}
