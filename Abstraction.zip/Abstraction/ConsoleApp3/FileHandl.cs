﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class FileHandl
    {
        static void Main(string[] args)
        {
            string fpath = @"C:\Users\csharp\Demo1.txt";
            {
                if (!File.Exists(fpath))
                {
                    File.Create(fpath);
                }
                else
                {
                    //using (StreamWriter sw = new StreamWriter(fpath))
                    //{
                    //    sw.WriteLine("This is line 1");
                    //    sw.WriteLine("This is line 2");
                    //    sw.WriteLine("This is line 3");
                    //    sw.WriteLine("This is line 4");
                    //}

                    //File.WriteAllText(fpath,"This is my Content");
                    
                    string[] lines = new string[]
                    {
                        "This is line 1",
                        "This is line 2",
                        "This is line 3",
                        "This is line 4"
                    };
                    File.WriteAllLines(fpath, lines);

                }
            }
        }
    }
}
