﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class FileHandl2
    {
        static void Main(string[] args)
        {
            string fpath = @"C:\Users\csharp\Demo1.txt";
            if (File.Exists(fpath))
            {
                FileInfo fi = new FileInfo(fpath);
                Console.WriteLine($"File Name: {fi.Name}");
                Console.WriteLine($"File Path: {fi.FullName}");
                Console.WriteLine($"File Directory: {fi.Directory}");
                Console.WriteLine($"File Extension: {fi.Extension}");
                Console.WriteLine($"File Size: {fi.Length} Bytes");

            }
        }
    }
}
