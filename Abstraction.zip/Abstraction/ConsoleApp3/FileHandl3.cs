﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class FileHandl3
    {
        static void Main(string[] args)
        {
            string dirpath = @"C:\Users\csharp\Dotnet";

            if (Directory.Exists(dirpath))
            {
                Directory.CreateDirectory(dirpath);
                Console.WriteLine("Directory Created Successfully");
            }
            else
            {
                Console.WriteLine("Directory Already Exists");
            }
        }
    }
}
