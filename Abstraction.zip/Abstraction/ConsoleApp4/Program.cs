﻿namespace ConsoleApp4
{
    class Customer
    {
        long _id; string _name; char _gender; string _email; string _contactNumber; DateTime _createdOn;
        public long Id { get => _id; set => _id = value; }
        public string Name { get => _name; set => _name = value; }
        public char Gender { get => _gender; set => _gender = value; }
        public string Email { get => _email; set => _email = value; }
        public string ContactNumber { get => _contactNumber; set => _contactNumber = value; }
        public DateTime CreatedOn { get => _createdOn; set => _createdOn = value; }


        public Customer(long _id, string _name, char _gender, string _email, string _contactNumber, DateTime _createdOn)
        {
            Id = _id;Name = _name; Gender = _gender; Email = _email; ContactNumber = _contactNumber;CreatedOn = _createdOn;
        }

        public override bool Equals(object? obj)
        {
            if (obj is Customer cust)
            {
                return cust.ContactNumber == ContactNumber && cust.Email == Email;
            }
            return false;
        }

        public override string ToString()
        {
            return $"Id : {Id} \r\n Customer : {Name} \r\n Contact details : {ContactNumber} , {Gender}, {Email} \r\n Created on: {CreatedOn}";
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer[] c = new Customer[2];

            for (int i = 0; i < c.Length; i++)
            {
                Console.WriteLine($"Customer {i + 1}:");
                Console.WriteLine("Enter Customer Id:");
                long _id = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter Customer Name:");
                string _name = Console.ReadLine();
                Console.WriteLine("Enter Gender:");
                char _gender = Console.ReadLine()[0];
                Console.WriteLine("Enter Email:");
                string _email = Console.ReadLine();
                Console.WriteLine("Enter Contact Number:");
                string _contactNumber = Console.ReadLine();
                Console.WriteLine("Enter Created On:");
                DateTime _createdOn = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy HH:mm:ss", null);

                c[i] = new Customer(_id, _name, _gender, _email, _contactNumber, _createdOn);
            }

            Console.WriteLine(c[0].ToString());
            Console.WriteLine(c[1].ToString());
            if (c[0].Equals(c[1]))
            {
                Console.WriteLine("Both customers are same");
            }
            else
            {
                Console.WriteLine("Both customers are different");
            }
        }
    }
}
