﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Alist
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add(16);
            al.Add(56.36);
            al.Add(true);
            al.Add('H');
            al.Add("India");
            al.Add(DateTime.Now);

            int[] arr= new int[] { 10, 20, 30, 40, 50 };
            al.AddRange(arr);
            
            
            al.Remove(10);
            al.RemoveAt(0);
            al.RemoveRange(3, 1);

            for (int i=0; i<al.Count; i++)
            {
                Console.WriteLine(al[i] + ":" + al[i].GetType());
            }

            foreach(var i in al)
            {
                Console.WriteLine(i + ":" + i.GetType());
            }
        }
    }
}
