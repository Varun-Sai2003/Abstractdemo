﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Lili
    {
        static void Main(string[] args)
        {
            LinkedList<string> l1 = new LinkedList<string>();

            l1.AddFirst("Vue");
            l1.AddLast("Angular");
            l1.AddLast("React");
            l1.AddLast("C#");
            l1.AddAfter(l1.Find("Angular"), "Java");
            l1.AddBefore(l1.Find("C#"),"Python");

            for (int i = 0; i<l1.Count;i++)
            {
                Console.WriteLine(l1.ElementAt(i));
            }


        }
    }
}
