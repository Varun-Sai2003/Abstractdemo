﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Soset
    {
        static void Main(string[] args)
        {
            SortedSet<string> s1 = new SortedSet<string>()
            {
                "Vue",
                "Angular",
                "React"
            };

            s1.Add("C#");
            s1.Add("Python");
            s1.Add("Java");

            foreach (var i in s1)
            {
                Console.WriteLine(i);
            }
        }
    }
}
