﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Blist
    {
        static void Main(string[] args)
        {
            List<string> courselist = new List<string>();
            courselist.Add("C#");
            courselist.Add("Java");
            courselist.Add("Python");
            courselist.Add("C++");
            courselist.Add("Ruby");

            string[] courses = new string[] {"Vue", "React", "Angular" };
            courselist.AddRange(courses);
            courselist.Sort();
            courselist.Remove("C++");
            foreach (var i in courselist)
            {
                Console.WriteLine(i);
            }
        }
    }
}
