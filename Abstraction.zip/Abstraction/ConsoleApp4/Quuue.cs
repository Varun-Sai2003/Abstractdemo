﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApp4
{
    class Quuue
    {
        static void Main(string[] args)
        {
            Queue qu = new Queue();
            qu.Enqueue(10);
            qu.Enqueue(20);
            qu.Enqueue(30);
            qu.Enqueue(40);
            qu.Enqueue(50);

            foreach (var i in qu)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("Deleted element: "+qu.Dequeue());
            Console.WriteLine("Deleted element: "+ qu.Dequeue());

            Console.WriteLine("The remaining elements in queue are:");
            foreach (var i in qu)
            {
                Console.WriteLine(i);
            }

        }
    }
}
