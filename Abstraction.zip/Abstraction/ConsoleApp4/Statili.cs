﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public static string CollegeName { get; set; } = "ABC College";
    }
    class Statili
    {
        static void Main(string[] args)
        {

            Student s1 = new Student();
            s1.Id = 101;
            s1.Name = "John";
            Console.WriteLine($"Id: {s1.Id} \tName: {s1.Name}\tCollege name:{Student.CollegeName}");

            Student.CollegeName = "ABC University";
            Student s2 = new Student();
            s2.Id = 102;
            s2.Name = "Smith";
            Console.WriteLine($"Id: {s2.Id} \tName: {s2.Name}\tCollege name:{Student.CollegeName}");

        }
    }
}
