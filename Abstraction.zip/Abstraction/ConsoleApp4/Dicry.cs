﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Dicry
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> d1 = new Dictionary<int, string>()
            {
                {1, "Vue"},
                {2, "Angular"},
                {3, "React"}
            };

            d1.Add(4, "C#");
            d1.Add(5, "Python");
            d1.Add(6, "Java");

            d1.Remove(1);

            for(int i = 1; i <= d1.Count; i++)
            {
                Console.WriteLine(d1.ElementAt(i).Key+"-"+ d1.ElementAt(i).Value);
            }
            foreach (var i in d1)
            {
                Console.WriteLine(i.Key + " - " + i.Value);
            }
        }
    }
}
