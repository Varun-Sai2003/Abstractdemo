﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Haset
    {
        static void Main(string[] args)
        {
            HashSet<string> h1 = new HashSet<string>()
            {
                "Vue",
                "Angular",
                "React"
            };

            h1.Add("C#");
            h1.Add("Java");
            h1.Add("Python");
            h1.Add("Angular");

            foreach (var i in h1)
            {
                Console.WriteLine(i);
            }
        }
    }
}
