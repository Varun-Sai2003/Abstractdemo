﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Util
    {
        public static void Print()
        {
            Console.WriteLine("Hi");
        }

        public static void Greet()
        {
            Console.WriteLine("Good Afternon");
        }

    }
    class Statila
    {
        static void Main(string[] args)
        {
            Util.Print();
            Util.Greet();
        }
    }
}
