﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Stakk
    {
        static void Main(string[] args)
        {
            Stack s1 = new Stack();
            s1.Push(10);
            s1.Push(20);
            s1.Push(30);
            s1.Push(40);
            s1.Push(50);


            foreach (var i in s1)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("Deleted elment: "+s1.Pop());
            Console.WriteLine("Deleted elment: " + s1.Pop());

            Console.WriteLine("The remaining elements in stack are:");
            foreach (var i in s1)
            {
                Console.WriteLine(i);
            }
        }
    }
}
