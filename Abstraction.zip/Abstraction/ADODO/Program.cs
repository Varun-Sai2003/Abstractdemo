﻿using System.Data;

namespace ADODO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataTable dt = new DataTable("Products");

            //adding columns
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Price", typeof(double));

            //adding rows
            DataRow dr = dt.NewRow();
            dr[0] = 101;
            dr[1] = "Dell 3525";
            dr[2] = 45000;
            dt.Rows.Add(dr);
            dt.Rows.Add(102,"Lenovo Thinkpad",75000);
            dt.Rows.Add(103,"OnePlus TM19",21000);

            //Printing table details
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine($"Table:{dt.TableName}");
            Console.WriteLine($"Columns:{dt.Columns.Count}");
            Console.WriteLine($"Rows:{dt.Rows.Count}");
            Console.WriteLine("----------------------------------------------");

            //Printing Columns
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                Console.Write($"{dt.Columns[i].ColumnName}".PadRight(20));

            }
            Console.WriteLine("\n----------------------------------------------");

            //Printing Rows
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    Console.Write($"{dt.Rows[i][j]}".PadRight(20));

                }
                Console.WriteLine();
            }
        }
    }
}
