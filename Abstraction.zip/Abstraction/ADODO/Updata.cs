﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODO
{
    class Updata
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Id");
            int _id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Name");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter City");
            string _city = Console.ReadLine();

            string constr = "Data Source=WIN2019;Initial Catalog=testdb;Integrated Security=true;TrustServerCertificate=true";
            SqlConnection con = new SqlConnection(constr);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            //cmd.CommandText = "update users set city = @city, name = @name where id = @id";
            //cmd.Parameters.AddWithValue("@id", _id);
            //cmd.Parameters.AddWithValue("@name", _name);
            //cmd.Parameters.AddWithValue("@city", _city);
            cmd.CommandText = $"update users set city = '{_city}' ,name = '{_name}' where id = {_id}";

            con.Open();
            int rowsupdated = (cmd.ExecuteNonQuery());
            Console.WriteLine($"{rowsupdated} Row(s) Updated Successfully!!");
            con.Close();

        }
    }
}
