﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Data;

namespace ADODO
{
    class Sqlcontion
    {
        static void Main(string[] args)
        {
            string constr = "Data Source=WIN2019;Initial Catalog=testdb;Integrated Security=true;TrustServerCertificate=true";
            SqlConnection con = new SqlConnection(constr);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.CommandText = "create table users(id int identity(9001,1) primary key, name varchar(20), city varchar(20))";

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
    }
}
