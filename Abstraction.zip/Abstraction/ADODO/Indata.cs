﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODO
{
    class Indata
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter City");
            string _city = Console.ReadLine();

            string constr = "Data Source=WIN2019;Initial Catalog=testdb;Integrated Security=true;TrustServerCertificate=true";
            SqlConnection con = new SqlConnection(constr);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            //cmd.CommandText = "insert into users(name,city) values (@name,@city)";
            //cmd.Parameters.AddWithValue("@name", _name);
            //cmd.Parameters.AddWithValue("@city", _city);
            cmd.CommandText= $"insert into users(name,city) values ('{_name}','{_city}')";

            con.Open();
            int rowsInserted=(cmd.ExecuteNonQuery());
            Console.WriteLine($"{rowsInserted} Row(s) Inserted Successfully!!");
            con.Close();
        }
    }
}
