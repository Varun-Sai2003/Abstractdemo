﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODO
{
    class Datemo
    {
        static void Main(string[] args)
        {
            DataSet ds = new DataSet();

            DataTable dt = new DataTable("Staff");
            DataTable dt1 = new DataTable("Students");

            ds.Tables.Add(dt);
            ds.Tables.Add(dt1);

            dt.Columns.Add("EmployeeId", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Designation", typeof(string));

            DataRow dr = dt.NewRow();
            dt.Rows.Add(101, "Rakesh", "Admin");
            dt.Rows.Add(102, "Prashanth", "Admin");
            dt.Rows.Add(103, "Rajesh", "Admin");

            dt1.Columns.Add("Id", typeof(int));
            dt1.Columns.Add("Name", typeof(string));
            dt1.Columns.Add("Age", typeof(int));

            DataRow dr1 = dt1.NewRow();
            dt1.Rows.Add(201, "Rahul", 25);
            dt1.Rows.Add(202, "Rohit", 26);
            dt1.Rows.Add(203, "Raj", 27);

           for(int i = 0; i <ds.Tables.Count; i++)
            {
                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine($"Table Name:{ds.Tables[i].TableName}");
                Console.WriteLine($"Columns:{ds.Tables[i].Columns.Count}");
                Console.WriteLine($"Rows:{ds.Tables[i].Rows.Count}");
                Console.WriteLine("---------------------------------------------------------------");


                //printing columns
                for (int j = 0; j < ds.Tables[i].Columns.Count; j++)
                {
                    Console.Write($"{ds.Tables[i].Columns[j].ColumnName}".PadRight(20));
                }
                Console.WriteLine();
                Console.WriteLine("---------------------------------------------------------------");

                //printing rows
                for (int k = 0; k < ds.Tables[i].Rows.Count; k++)
                {
                    for (int l = 0; l < ds.Tables[i].Columns.Count; l++)
                    {
                        Console.Write($"{ds.Tables[i].Rows[k][l]}".PadRight(20));
                    }
                    Console.WriteLine();
                }

                Console.WriteLine("\n\n---------------------------------------------------------------");

            }


        }
    }
}
