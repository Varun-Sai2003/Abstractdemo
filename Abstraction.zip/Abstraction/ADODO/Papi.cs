﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ADODO
{
    class Papi
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter the Vehicle Registration number:");
            //string _regno = Console.ReadLine();

            //string p = $"{_regno.Substring(0, 2)}-{_regno.Substring(2, 2)}-{_regno.Substring(4, 2)}-{_regno.Substring(6, 4)}";
            //Console.WriteLine(p);

            Console.WriteLine("Enter the string:");
            string _str = Console.ReadLine();

            int i = 0;
            char[] cv = new char[_str.Length];

            foreach (char c in _str)
            {
                if ("aeiouAEIOU".Contains(c) && !cv.Contains(c))
                {
                    i++;
                    cv[i] = c;
                }
            }
            Console.WriteLine($"Vowels: {i}");

            string _newstr = Regex.Replace(_str, "[aeiouAEIOU]", "");
            Console.WriteLine(_newstr);
        }
    }
}
