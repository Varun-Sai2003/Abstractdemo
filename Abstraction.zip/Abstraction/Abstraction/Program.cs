﻿namespace Abstraction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int choice;
            Chair[] c = new Chair[5];
            BookShelf[] b = new BookShelf[5];
            Furniture[] f = new Furniture[5];  
            while (i < 3)
            {
                Console.WriteLine("Enter your choice 1.Chair 2.BookShelf: ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        /*c[i] = new Chair();
                        c[i].Accept();
                        c[i].Display(); */
                        f[i] = new Chair();
                        f[i].Accept();
                        break; 
                    case 2:
                        /*b[i] = new BookShelf();
                        b[i].Accept();
                        b[i].Display(); */
                        f[i] = new BookShelf();
                        f[i].Accept();
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
                i++;
                foreach (Furniture ch in f)
                {
                    if (ch != null)
                        ch.Display();
                }
            }
        }
    }
}
