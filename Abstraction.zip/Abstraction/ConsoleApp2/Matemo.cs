﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Matemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.PI);
            Console.WriteLine(Math.Abs(-10.6));
            Console.WriteLine(Math.Abs(+10.6));
            Console.WriteLine(Math.Ceiling(10.6));
            Console.WriteLine(Math.Floor(10.6));
            Console.WriteLine(Math.Round(10.2));
            Console.WriteLine(Math.Round(10.5));
            Console.WriteLine(MathF.Cos(80));
            Console.WriteLine(Math.Sign(25));
        }
    }
}
