﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Datdem
    {
        static void Main(string[] args)
        {
            DateTime dt = DateTime.Now;
            Console.WriteLine(dt);

            DateTime dt1 = DateTime.Parse("2016-12-25 12:22:12");
            Console.WriteLine(dt1);

            DateTime dt2 = DateTime.ParseExact("2018/18/03 16:25:32", "yyyy/dd/MM HH:mm:ss",null);
            Console.WriteLine(dt2);

            Console.WriteLine(dt.Year);
            Console.WriteLine(dt.Month);
            Console.WriteLine(dt.Day);
            Console.WriteLine(dt.Hour);
            Console.WriteLine(dt.Minute);
            Console.WriteLine(dt.Second);
            Console.WriteLine(dt.Millisecond);
            Console.WriteLine(dt.ToString("dd/MM/yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.ToString("dd/MMM/yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.ToString("dd/MMMM/yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.DayOfWeek);
            Console.WriteLine(dt.DayOfYear);
            Console.WriteLine(DateTime.IsLeapYear(dt.Year) ? "It's a leap year" : "Not a leap year");

            int years = dt.Year - dt1.Year;
            Console.WriteLine($"Years : {years}");

            int days = (dt - dt1).Days;
            Console.WriteLine($"Days : {days}");
        }
    }
}