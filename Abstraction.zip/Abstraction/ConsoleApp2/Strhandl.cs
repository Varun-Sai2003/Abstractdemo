﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Strhandl
    {
        static void Main(string[] args)
        {
            string s = "India";
            Console.WriteLine(s);
            Console.WriteLine($"{s}(+91)");
            Console.WriteLine(s);

            StringBuilder sb = new StringBuilder("India");
            Console.WriteLine(sb);
            Console.WriteLine(sb.Append("(+91)"));
            Console.WriteLine(sb);

            string str = "I am from India";
            Console.WriteLine(str.Length);
            Console.WriteLine(str.ToUpper());
            Console.WriteLine(str.ToLower());
            Console.WriteLine(str.Trim());
            Console.WriteLine(str.Replace("from","in"));

            Console.WriteLine(str.Substring(8));
            Console.WriteLine(str.Substring(8, 4));
            Console.WriteLine(str.LastIndexOf('m'));
            Console.WriteLine(str.IndexOf('m'));
            Console.WriteLine(str[3]);

            Console.WriteLine(str.StartsWith("I am"));
            Console.WriteLine(str.EndsWith("India"));

            string str1 = "$$$$$India$$$$$";
            Console.WriteLine(str1.TrimStart('$'));
            Console.WriteLine(str1.TrimEnd('$'));
            Console.WriteLine(str1.PadLeft(20,'*'));
            Console.WriteLine(str1.PadRight(20,'*'));

            string str2 = "I am from India";
            string str3 = "I am from India";
            Console.WriteLine(str2.Equals(str3));
            Console.WriteLine(str2.Equals(str3,StringComparison.InvariantCultureIgnoreCase));

            Console.WriteLine(str2.CompareTo(str3));
            Console.WriteLine(str2.ToLower().CompareTo(str3.ToLower()));
        }
    }
}
