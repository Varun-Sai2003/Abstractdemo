﻿using System.Text.RegularExpressions;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter User Id:");
            string mob = Console.ReadLine();

            if (Regex.IsMatch(mob, "^[A-Za-z]{5}[A-Za-z0-9_.&$@?]{7,19}$"))
            {
                Console.WriteLine("Valid User Id !!");
            }
            else
            {
                Console.WriteLine("Invalid User Id !!");
            }
        }
    }
}

