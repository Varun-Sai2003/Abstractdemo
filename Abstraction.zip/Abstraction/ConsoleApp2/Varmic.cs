﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Varmic
    {
        static void Main(string[] args)
        {
            var x=15;
            Console.WriteLine($"{x}-{x.GetTypeCode()}");

            dynamic d;
            d = 16;
            Console.WriteLine($"{d}-{d.GetTypeCode()}");
            d = "India";
            Console.WriteLine($"{d}-{d.GetTypeCode()}");
            d = 10.5;
            Console.WriteLine($"{d}-{d.GetTypeCode()}");
            d = true;
            Console.WriteLine($"{d}-{d.GetTypeCode()}");

            string s = "Test";
            object o = s;
            Console.WriteLine($"{o}-{o.GetType()}");

            string y = (string)o;
            Console.WriteLine($"{y}-{y.GetType()}");
        }
    }
}
