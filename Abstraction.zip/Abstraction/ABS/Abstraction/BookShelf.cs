﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    class BookShelf:Furniture
    {
        int noOfShelves;
        internal override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter the number of shelves in the bookshelf");
            noOfShelves = Convert.ToInt32(Console.ReadLine());
        }
        internal override void Display()
        {
            base.Display();
            Console.WriteLine($"Number of shelves:{noOfShelves}");
        }
    }
}
