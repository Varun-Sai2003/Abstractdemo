﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockLibrary
{
    public class Stock
    {
        protected internal string Name;
        private protected float Qty;
        void check()
        {
            Qty = 10;
        }
    }

    class Items : Stock
    {
        void Add()
        {
            Qty = 44;
        }
    }
}
