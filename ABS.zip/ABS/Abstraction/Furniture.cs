﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    class Furniture
    {
        string color;
        int width;
        int height;

        internal virtual void Accept()
        {
            Console.WriteLine("Enter the color of the furniture");
            color = Console.ReadLine();
            Console.WriteLine("Enter the width of the furniture");
            width = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the height of the furniture");
            height = Convert.ToInt32(Console.ReadLine());
        }

        internal virtual void Display()
        {
            Console.WriteLine($"Color:{color} Width:{width} height:{height}");
        }
    }
}
