﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    class Chair : Furniture
    {
        int noOfLegs;
        internal override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter the number of legs of the chair");
            noOfLegs = Convert.ToInt32(Console.ReadLine());
        }

        internal override void Display()
        {
            base.Display();
            Console.WriteLine($"Number of legs:{noOfLegs}");
        }
    }
}
